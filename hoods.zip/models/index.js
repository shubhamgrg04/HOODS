var mongoose = require('mongoose');
export * from './PostData';